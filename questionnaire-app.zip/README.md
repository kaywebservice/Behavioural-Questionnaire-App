
# Simple Questionnaire App

This is a simple full-stack questionnaire app demonstrating basic React frontend and Node.js backend.

## Frontend

- React app with multiple-choice questions
- Displays simple profile result after submit

## Backend

- Node.js with Express backend (placeholder)

## Run Instructions

1. Frontend:
```
cd frontend
npm install
npm start
```
2. Backend:
```
cd backend
npm install
npm start
```
